#pragma once

#include "unit-tests_Namespace.h"
#include <gtest/gtest.h>
#include <gmock/gmock.h>

BEGIN_UNIT_TESTS_NAMESPACE

END_UNIT_TESTS_NAMESPACE
